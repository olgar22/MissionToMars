from splinter import Browser
import pandas as pd
from bs4 import BeautifulSoup
import requests
import os, io


    # @NOTE: Replace the path with your actual path to the chromedriver
   
def scrape_info():
    url_base='https://mars.nasa.gov'
    url = url_base + '/news'
    response = requests.get(url)
    soup = BeautifulSoup(response.text, 'html.parser')
    news_div =soup.find('div', {'class': 'content_title'})
    news_a = news_div.find('a')
    article_url = url_base + news_a.get_attribute_list('href')[0]
    article_title = news_a.text          ######################      article_title    ######################
    response = requests.get(article_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    news_div =soup.find('div', {'class': 'wysiwyg_content'})
    news_paragraph = news_div.find('p').text 
    image_url_base = 'https://astrogeology.usgs.gov'
    image_url_ext = '/maps/mars-viking-hemisphere-point-perspectives'
    response = requests.get(image_url_base + image_url_ext)
    soup = BeautifulSoup(response.text, 'html.parser')
    image_div =soup.find('div', {'class': 'slide'})
    image_tag =image_div.find('img')
    image_source = image_tag.get_attribute_list('src')[0]
    image_url = image_url_base + image_source           #########   feature image ##############
    #twitter
    twitter_url = 'https://twitter.com/marswxreport?lang=en'
    response = requests.get(twitter_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    mars_weathers = soup.find_all('div', {'class' : 'js-tweet-text-container'})
    tweet_text = ''
    for mars_weather in mars_weathers:
        mars_weather_text=mars_weather.text
        if mars_weather_text.find('pressure') >=0 :
            tweet_text = mars_weather_text
            break
    if tweet_text =='' :
        print('could not find weather')                       ######## tweet_text   ########### 
    
    facts_url = 'http://space-facts.com/mars/'
    tables = pd.read_html(facts_url)                ############ table of mars facts ################
    #hemispheres
    image_url_base = 'https://astrogeology.usgs.gov'
    image_url_ext = '/maps/mars-viking-hemisphere-point-perspectives'
    images_url = image_url_base + image_url_ext
    hemisphere_image_urls = []
    hemisphere_image = {}
    image_list = []
    response = requests.get(images_url)
    soup = BeautifulSoup(response.text, 'html.parser')
    container = soup.find('div', {'class' : 'widget block products'})
    images= container.find_all('a')     #find all elements containing title and link to wide size image
    for image in images:
        title = image.find('h3').text    #this is the image title
        if title.find('Enhanced') >=0:      #loop through all titles to work with 'enhanced' only
            deep_image_url = image_url_base + image.get_attribute_list('href')[0]   #use this url to get to the wide size picture
            response1 = requests.get(deep_image_url)
            soup1 = BeautifulSoup(response1.text, 'html.parser')
            wide_image_url = soup1.find('img', {'class': 'wide-image'})    #here we are looking for the url of the wide image
            ############# url of the Hemisphere image ##############
            image_source = image_url_base + wide_image_url.get_attribute_list('src')[0]
            hemisphere_image = {
                "title": title,
                "img_url": image_source
            }
            hemisphere_image_urls.append(hemisphere_image)
    #collect everything in one dict
        # print(article_title)                      ######################      article_title    ######################
        # print(image_url)                           #############   feature image ####################
        # print(news_paragraph)                    ############################    news_paragraph    ############### 
        # print(hemisphere_image_urls )             ##############  this is the list of dict's of hemisphere image url's
        # print(tweet_text  )                     ######## tweet_text   ###########
        # print(tables)                       ############# mars facts

     #dict to hold all vars
    str_io =io.StringIO()
    tables[0].to_html(buf=str_io, classes='table table-striped')
    html_str = str_io.getvalue()
    #print(html_str)

    mars_data = {
        'article_title' : article_title,
        'image_url': image_url,
        'news_paragraph': news_paragraph,
        'hemisphere_image_urls': hemisphere_image_urls,
        'tweet_text': tweet_text,
        'tables': html_str
        }
    # Return results
    return mars_data
